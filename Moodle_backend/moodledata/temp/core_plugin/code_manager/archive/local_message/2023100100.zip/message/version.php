<?php

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_message';
$plugin->version = 2023100100;
$plugin->requires = 2022112800;
