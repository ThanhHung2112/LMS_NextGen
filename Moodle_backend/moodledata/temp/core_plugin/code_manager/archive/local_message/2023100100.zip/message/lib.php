<?php

function local_message_before_footer() { 
    \core\notification::add("Trung đẹp trai vãi l", \core\output\notification::NOTIFY_SUCCESS);
}